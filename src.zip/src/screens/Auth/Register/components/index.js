export { default as RegisterInput } from './input';

export {default as ProfileSettings} from './settings';
export {default as EditPhoto} from './editPhoto';

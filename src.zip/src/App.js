import React, {Component} from 'react';
import Router from './router';

class App extends Component {
  render() {
    return <Router />;
  }
}

export default App;

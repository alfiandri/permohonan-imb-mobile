// Home
export const SET_HOME = 'SET_HOME';
export const RESET_HOME = 'RESET_HOME';

// Login
export const SET_LOGIN = 'SET_LOGIN';
export const LOGOUT = 'LOGOUT';

// Profile
export const SET_PROFILE = 'SET_PROFILE';
export const RESET_PROFILE = 'RESET_PROFILE';

// Filters
export const ADD_FILTER = 'ADD_FILTER';
export const RESET_FILTER = 'RESET_FILTER';
